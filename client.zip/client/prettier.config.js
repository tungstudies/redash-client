module.exports = {
  printWidth: 120,
  jsxBracketSameLine: true,
  tabWidth: 2,
  trailingComma: 'es5',
};
