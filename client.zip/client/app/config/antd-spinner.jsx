import React from "react";
import Spin from "antd/lib/spin";

Spin.setDefaultIndicator(<i className="fa fa-spinner fa-pulse" />);
