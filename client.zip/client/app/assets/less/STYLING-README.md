# Styling readme

Some general rules before you add stuff.

- Avoid using inline css
- If possible, use classes that are already in place instead of adding new
- Keep less/inc folder untouched, rewrite things in less/redash respectively 
- Try following BEM naming conventions: http://getbem.com/naming/
